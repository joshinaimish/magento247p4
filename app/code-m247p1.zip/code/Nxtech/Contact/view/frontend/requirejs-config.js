var config = {
    map: {
        "*": {
            contactForm: "Nxtech_Contact/js/contact-form",
        },
    },
};
