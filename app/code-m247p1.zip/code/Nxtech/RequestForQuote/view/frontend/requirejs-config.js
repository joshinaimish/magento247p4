var config = {
    paths: {
        rfq: "Nxtech_RequestForQuote/js/rfq",
    },
    shim: {
        rfq: {
            deps: ["jquery"],
        },
    },
};
