/**
 * @author nxtech
 */
var config = {
    map: {
        "*": {
            "Magento_Checkout/js/model/shipping-save-processor/default":
                "Nxtech_CheckoutField/js/model/shipping-save-processor/default",
        },
    },
    /* config: {
        mixins: {
            "Magento_Checkout/js/action/set-shipping-information": {
                "Nxtech_CheckoutField/js/action/set-shipping-information-mixin": true,
            },
        },
    }, */
};
