<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace WebxCreative\Services\Model;

use Magento\Framework\Model\AbstractModel;
use WebxCreative\Services\Api\Data\ServicesInterface;

class Services extends AbstractModel implements ServicesInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\WebxCreative\Services\Model\ResourceModel\Services::class);
    }

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * @inheritDoc
     */
    public function setId($servicesId)
    {
        return $this->setData(self::ID, $servicesId);
    }

    /**
     * @inheritDoc
     */
    public function getServiceName()
    {
        return $this->getData(self::SERVICE_NAME);
    }

    /**
     * @inheritDoc
     */
    public function setServiceName($serviceName)
    {
        return $this->setData(self::SERVICE_NAME, $serviceName);
    }

    /**
     * @inheritDoc
     */
    public function getServiceShortDescription()
    {
        return $this->getData(self::SERVICE_SHORT_DESCRIPTION);
    }

    /**
     * @inheritDoc
     */
    public function setServiceShortDescription($serviceShortDescription)
    {
        return $this->setData(self::SERVICE_SHORT_DESCRIPTION, $serviceShortDescription);
    }

    /**
     * @inheritDoc
     */
    public function getServiceImage()
    {
        return $this->getData(self::SERVICE_IMAGE);
    }

    /**
     * @inheritDoc
     */
    public function setServiceImage($serviceImage)
    {
        return $this->setData(self::SERVICE_IMAGE, $serviceImage);
    }

    /**
     * @inheritDoc
     */
    public function getServiceCategoryId()
    {
        return $this->getData(self::SERVICE_CATEGORY_ID);
    }

    /**
     * @inheritDoc
     */
    public function setServiceCategoryId($serviceCategoryId)
    {
        return $this->setData(self::SERVICE_CATEGORY_ID, $serviceCategoryId);
    }

    /**
     * @inheritDoc
     */
    public function getServiceCmsPageId()
    {
        return $this->getData(self::SERVICE_CMS_PAGE_ID);
    }

    /**
     * @inheritDoc
     */
    public function setServiceCmsPageId($serviceCmsPageId)
    {
        return $this->setData(self::SERVICE_CMS_PAGE_ID, $serviceCmsPageId);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }
}

