<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace WebxCreative\Services\Controller\Adminhtml\Services;

use Magento\Framework\Exception\LocalizedException;
use WebxCreative\Services\Model\ImageUploader;
class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    protected $imageUploaderModel;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        ImageUploader $imageUploaderModel
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->imageUploaderModel = $imageUploaderModel;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        if ($data) {
            $id = $this->getRequest()->getParam('id');

            $model = $this->_objectManager->create(\WebxCreative\Services\Model\Services::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Services no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            if ($model->getId()) {
                $data['updated_at'] = date('y-m-d h:i:s');
            } else {
                $data['created_at'] = date('y-m-d h:i:s');
                $data['updated_at'] = date('y-m-d h:i:s');
            }

            $model->setData($data);
            $model = $this->imageData($model, $data);

            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('You saved the Services.'));
                $this->dataPersistor->clear('webxcreative_services_services');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Services.'));
            }

            $this->dataPersistor->set('webxcreative_services_services', $data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
    public function imageData($model, $data)
    {
        if ($model->getId()) {
            $pageData = $this->_objectManager->create(\WebxCreative\Services\Model\Services::class)->load($model->getId());
            //$pageData = $this->blogRepository->get($model->getId());

            if (isset($data['service_image'][0]['name'])) {
                $imageName1 = $pageData->getServiceImage();
                $imageName2 = $data['service_image'][0]['name'];
                if ($imageName1 != $imageName2) {
                    $imageUrl = $data['service_image'][0]['url'];
                    $imageName = $data['service_image'][0]['name'];
                    $data['service_image'] = $this->imageUploaderModel->saveMediaImage($imageName, $imageUrl);
                } else {
                    $data['service_image'] = $data['service_image'][0]['name'];
                }
            } else {
                $data['service_image'] = '';
            }
        } else {
            if (isset($data['service_image'][0]['name'])) {
                $imageUrl = $data['service_image'][0]['url'];
                $imageName = $data['service_image'][0]['name'];
                $data['service_image'] = $this->imageUploaderModel->saveMediaImage($imageName, $imageUrl);
            }
        }
        $model->setData($data);
        return $model;
    }
}

