<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace WebxCreative\Services\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use WebxCreative\Services\Api\Data\ServicesInterface;
use WebxCreative\Services\Api\Data\ServicesInterfaceFactory;
use WebxCreative\Services\Api\Data\ServicesSearchResultsInterfaceFactory;
use WebxCreative\Services\Api\ServicesRepositoryInterface;
use WebxCreative\Services\Model\ResourceModel\Services as ResourceServices;
use WebxCreative\Services\Model\ResourceModel\Services\CollectionFactory as ServicesCollectionFactory;

class ServicesRepository implements ServicesRepositoryInterface
{

    /**
     * @var ServicesCollectionFactory
     */
    protected $servicesCollectionFactory;

    /**
     * @var ServicesInterfaceFactory
     */
    protected $servicesFactory;

    /**
     * @var ResourceServices
     */
    protected $resource;

    /**
     * @var Services
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;


    /**
     * @param ResourceServices $resource
     * @param ServicesInterfaceFactory $servicesFactory
     * @param ServicesCollectionFactory $servicesCollectionFactory
     * @param ServicesSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceServices $resource,
        ServicesInterfaceFactory $servicesFactory,
        ServicesCollectionFactory $servicesCollectionFactory,
        ServicesSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->servicesFactory = $servicesFactory;
        $this->servicesCollectionFactory = $servicesCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(ServicesInterface $services)
    {
        try {
            $this->resource->save($services);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the services: %1',
                $exception->getMessage()
            ));
        }
        return $services;
    }

    /**
     * @inheritDoc
     */
    public function get($id)
    {
        $services = $this->servicesFactory->create();
        $this->resource->load($services, $id);
        if (!$services->getId()) {
            throw new NoSuchEntityException(__('Services with id "%1" does not exist.', $id));
        }
        return $services;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->servicesCollectionFactory->create();

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(ServicesInterface $services)
    {
        try {
            $servicesModel = $this->servicesFactory->create();
            $this->resource->load($servicesModel, $services->getId());
            $this->resource->delete($servicesModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Services: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($id)
    {
        return $this->delete($this->get($id));
    }
}

