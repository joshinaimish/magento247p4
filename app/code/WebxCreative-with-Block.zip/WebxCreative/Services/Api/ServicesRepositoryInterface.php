<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace WebxCreative\Services\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ServicesRepositoryInterface
{

    /**
     * Save Services
     * @param \WebxCreative\Services\Api\Data\ServicesInterface $services
     * @return \WebxCreative\Services\Api\Data\ServicesInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \WebxCreative\Services\Api\Data\ServicesInterface $services
    );

    /**
     * Retrieve Services
     * @param string $id
     * @return \WebxCreative\Services\Api\Data\ServicesInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($id);

    /**
     * Retrieve Services matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \WebxCreative\Services\Api\Data\ServicesSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Services
     * @param \WebxCreative\Services\Api\Data\ServicesInterface $services
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \WebxCreative\Services\Api\Data\ServicesInterface $services
    );

    /**
     * Delete Services by ID
     * @param string $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($id);
}

