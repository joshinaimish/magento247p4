<?php
namespace WebxCreative\Services\Block;

class Services extends \Magento\Framework\View\Element\Template
{
    protected $servicesFactory;
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \WebxCreative\Services\Model\ResourceModel\Services\CollectionFactory $servicesFactory,
        array $data = []
    ) {
        $this->servicesFactory = $servicesFactory;
        parent::__construct($context, $data);
    }
    public function getServiceCollection($categoryId)
    {
        $collection = $this->servicesFactory->create();
        $collection->addFieldToFilter('service_category_id', $categoryId);
        return $collection;
    }
}
