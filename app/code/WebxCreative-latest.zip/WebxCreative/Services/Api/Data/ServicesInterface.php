<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace WebxCreative\Services\Api\Data;

interface ServicesInterface
{

    const SERVICE_IMAGE = 'service_image';
    const UPDATED_AT = 'updated_at';
    const SERVICE_SHORT_DESCRIPTION = 'service_short_description';
    const SERVICE_CMS_PAGE_ID = 'service_cms_page_id';
    const SERVICE_NAME = 'service_name';
    const CREATED_AT = 'created_at';
    const SERVICE_CATEGORY_ID = 'service_category_id';
    const ID = 'id';

    /**
     * Get _id
     * @return string|null
     */
    public function getId();

    /**
     * Set id
     * @param string $id
     * @return \WebxCreative\Services\Services\Api\Data\ServicesInterface
     */
    public function setId($id);

    /**
     * Get service_name
     * @return string|null
     */
    public function getServiceName();

    /**
     * Set service_name
     * @param string $serviceName
     * @return \WebxCreative\Services\Services\Api\Data\ServicesInterface
     */
    public function setServiceName($serviceName);

    /**
     * Get service_short_description
     * @return string|null
     */
    public function getServiceShortDescription();

    /**
     * Set service_short_description
     * @param string $serviceShortDescription
     * @return \WebxCreative\Services\Services\Api\Data\ServicesInterface
     */
    public function setServiceShortDescription($serviceShortDescription);

    /**
     * Get service_image
     * @return string|null
     */
    public function getServiceImage();

    /**
     * Set service_image
     * @param string $serviceImage
     * @return \WebxCreative\Services\Services\Api\Data\ServicesInterface
     */
    public function setServiceImage($serviceImage);

    /**
     * Get service_category_id
     * @return string|null
     */
    public function getServiceCategoryId();

    /**
     * Set service_category_id
     * @param string $serviceCategoryId
     * @return \WebxCreative\Services\Services\Api\Data\ServicesInterface
     */
    public function setServiceCategoryId($serviceCategoryId);

    /**
     * Get service_cms_page_id
     * @return string|null
     */
    public function getServiceCmsPageId();

    /**
     * Set service_cms_page_id
     * @param string $serviceCmsPageId
     * @return \WebxCreative\Services\Services\Api\Data\ServicesInterface
     */
    public function setServiceCmsPageId($serviceCmsPageId);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \WebxCreative\Services\Services\Api\Data\ServicesInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \WebxCreative\Services\Services\Api\Data\ServicesInterface
     */
    public function setUpdatedAt($updatedAt);
}

