<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace WebxCreative\Services\Api\Data;

interface ServicesSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Services list.
     * @return \WebxCreative\Services\Api\Data\ServicesInterface[]
     */
    public function getItems();

    /**
     * Set service_name list.
     * @param \WebxCreative\Services\Api\Data\ServicesInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

