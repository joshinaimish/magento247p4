<?php
namespace Nxtech\TicketManager\Block\Adminhtml\TicketManager\Edit\TicketManager;

use Nxtech\TicketManager\Api\TicketManagerRepositoryInterface;

class TicketHistory extends \Magento\Framework\View\Element\Template
{

    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'ticket/history.phtml';

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        protected TicketManagerRepositoryInterface $ticketManagerRepository,
        protected \Nxtech\TicketManager\Model\ResourceModel\TicketChat\Collection $ticketChatCollection,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

    public function getTicketDetail()
    {
        $id = $this->getRequest()->getParam('id');
        $ticketData = $this->ticketManagerRepository->get($id);
        return $ticketData;
    }
    public function getTicketHistory($id)
    {
        //$collection = $this->ticketChatRepository->get($id);
        $collection = $this->ticketChatCollection->addFieldToFilter('ticket_id', $id);
        return $collection;
    }
}
