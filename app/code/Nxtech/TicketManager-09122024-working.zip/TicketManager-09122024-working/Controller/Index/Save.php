<?php
namespace Nxtech\TicketManager\Controller\Index;

use Magento\Framework\Exception\LocalizedException;
use Nxtech\TicketManager\Model\ImageUploader;
use Nxtech\TicketManager\Api\TicketManagerRepositoryInterface;
use Nxtech\TicketManager\Api\Data\TicketManagerInterface;
use Nxtech\TicketManager\Api\TicketChatRepositoryInterface;
use Nxtech\TicketManager\Api\Data\TicketChatInterface;

class Save extends \Magento\Framework\App\Action\Action
{
    const USER_TYPE = 'customer';
    const STATUS = 1;
    /**
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        protected ImageUploader $imageUploaderModel,
        protected TicketManagerRepositoryInterface $ticketManagerRepository,
        protected TicketManagerInterface $ticketManager,
        protected TicketChatRepositoryInterface $ticketChatRepository,
        protected TicketChatInterface $ticketChat,
        protected \Magento\Customer\Model\Session $customerSession,
        protected \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
    ) {

        return parent::__construct($context);
    }
    /**
     * View page action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        $customer = $this->getCustomerDetail();

        if ($data) {
            $id = $this->getRequest()->getParam('id');
            if ($id == "") {
                $model = $this->ticketManager;
                $data['status'] = self::STATUS;
                $data['created_at'] = date('y-m-d h:i:s');
            } else {
                $model = $this->ticketManagerRepository->get($id);
                if (!$model->getId() && $id) {
                    $this->messageManager->addErrorMessage(__('This Ticket no longer exists.'));
                    return $resultRedirect->setPath('*/*/');
                }
                $data['updated_at'] = date('y-m-d h:i:s');
            }

            $data['user_id'] = $customer->getEntityId();
            $data['user_type'] = self::USER_TYPE;
            $model->setData($data);

            try {
                $model->save();
                $ticketManagerId = $model->getId();
                $this->saveTicketChat($data, $ticketManagerId);
                $this->messageManager->addSuccessMessage(__('You saved the Ticketmanager.'));
                $this->dataPersistor->clear('ticketmanager');
                return $resultRedirect->setPath('ticket/index/edit', ['id' => $ticketManagerId]);
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Ticketmanager.'));
            }
            $this->dataPersistor->set('ticketmanager', $data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $ticketManagerId]);
        }
        return $resultRedirect->setPath('*/*/');
    }
    public function saveTicketChat($data, $ticketManagerId)
    {
        $chatData = [];
        $ticketChatModel = $this->ticketChat;
        $chatData['ticket_id'] = $ticketManagerId;
        $chatData['user_id'] = $data['user_id'];
        $chatData['user_type'] = $data['user_type'];
        $chatData['ticket_description'] = $data['ticket_description'];
        if (isset($data['attachment'])) {
            $chatData['attachment'] = $data['attachment'];
        }
        $chatData['created_at'] = date('y-m-d h:i:s');
        $chatData['updated_at'] = date('y-m-d h:i:s');

        $ticketChatModel->setData($chatData);
        if (isset($data['attachment'])) {
            $ticketChatModel = $this->imageData($ticketChatModel, $chatData);
        }

        try {
            $ticketChatModel->save();
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Ticket Chat.'));
        }
        return true;
    }
    /**
     * @param $ticketChatModel
     * @param $chatData
     * @return mixed
     */
    public function imageData($ticketChatModel, $chatData)
    {
        if (isset($chatData['attachment'][0]['name'])) {
            $imageUrl = $chatData['attachment'][0]['url'];
            $imageName = $chatData['attachment'][0]['name'];
            $chatData['attachment'] = $this->imageUploaderModel->saveMediaImage($imageName, $imageUrl);
        }
        $ticketChatModel->setData($chatData);
        return $ticketChatModel;
    }

    public function getCustomerDetail()
    {
        return $this->customerSession->getCustomer();
    }
}
